const letterToNumber = {
    'A': 1, 'B': 2, 'C': 3, 'D': 4, 'E': 5,
    'U': 6, 'O': 7, 'P': 8, 'I': 1, 'K': 2,
    'G': 3, 'M': 4, 'H': 5, 'V': 6, 'Z': 7,
    'F': 8, 'Q': 1, 'R': 2, 'L': 3, 'T': 4,
    'N': 5, 'W': 6, 'J': 1, 'S': 3, 'X': 5,
    'Y': 1
};

document.getElementById('inputForm').addEventListener('submit', function(event) {
    event.preventDefault();
    const inputType = document.getElementById('inputType').value;
    const inputValue = document.getElementById('inputValue').value.trim().toUpperCase();
    let baseNumbers = [];
    let phoneNumberSum = 0;

    if (inputType === 'name') {
        for (let char of inputValue) {
            if (letterToNumber[char] !== undefined) {
                baseNumbers.push(letterToNumber[char]);
            }
        }
    } else if (inputType === 'phone') {
        for (let char of inputValue) {
            if (!isNaN(char) && char !== ' ') {
                let digit = parseInt(char);
                baseNumbers.push(digit);
                phoneNumberSum += digit;
            }
        }
    }

    if (baseNumbers.length === 0) {
        document.getElementById('output').innerText = `The input does not contain any valid characters for ${inputType}.`;
    } else {
        const pyramidTop = pyramidNumber(baseNumbers);
        let outputText = `The top of the pyramid is: ${pyramidTop}\n\nPyramid:\n`;
        if (inputType === 'phone') {
            let phoneNumberSumTwoDigits = phoneNumberSum % 100;
            outputText += `The sum of the phone number digits is: ${phoneNumberSumTwoDigits}\n\n`;
        }
        document.getElementById('output').innerText = outputText + generatePyramidText(levels);
    }
});

function reduceToSingleDigit(num) {
    return num % 9 || 9;
}

function pyramidNumber(base) {
    levels = [base];
    while (base.length > 1) {
        let newLevel = [];
        for (let i = 0; i < base.length - 1; i++) {
            let sumDigits = base[i] + base[i + 1];
            let singleDigit = reduceToSingleDigit(sumDigits);
            newLevel.push(singleDigit);
        }
        base = newLevel;
        levels.push(base);
    }
    return levels[levels.length - 1][0];
}

function generatePyramidText(levels) {
    let output = '';
    const maxWidth = levels[0].length * 2 - 1;
    levels.forEach(level => {
        output += level.map(String).join(' ').padStart((maxWidth + level.length) / 2, ' ').padEnd(maxWidth, ' ') + '\n';
    });
    return output;
}
